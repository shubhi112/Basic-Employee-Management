export class Department{
    DepartmentId: number;
    DepartmentName: string
}