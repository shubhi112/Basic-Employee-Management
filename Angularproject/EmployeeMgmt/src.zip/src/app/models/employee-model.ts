export class Employee{
    EmployeeID:number
    EmployeeName: string
    Department: string
    MailID:string
    DOJ: Date
}